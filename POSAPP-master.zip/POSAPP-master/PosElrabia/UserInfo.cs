﻿using PosElrabia.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace PosElrabia
{
   public   class UserInfo
    {
        //Hello
        public static Employee employee = null;
      
    }
}
